package com.nirmalyasen.cinematicwallpapers

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    data class Wallpaper(val title: String, val color: Int)
    private val wallpapers = listOf(
        Wallpaper("Midnight Mountains", 0xFF151B2D.toInt()),
        Wallpaper("Neon City", 0xFF30154A.toInt()),
        Wallpaper("Golden Dawn", 0xFF6B3A20.toInt()),
        Wallpaper("Rainy Forest", 0xFF183B38.toInt()),
        Wallpaper("Moonlit Lake", 0xFF182B45.toInt()),
        Wallpaper("Desert Cinema", 0xFF704522.toInt())
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val grid = findViewById<RecyclerView>(R.id.grid)
        grid.layoutManager = GridLayoutManager(this, 2)
        grid.adapter = WallpaperAdapter(wallpapers) { w ->
            Toast.makeText(this, "${w.title}: preview ready", Toast.LENGTH_SHORT).show()
        }
    }
}
