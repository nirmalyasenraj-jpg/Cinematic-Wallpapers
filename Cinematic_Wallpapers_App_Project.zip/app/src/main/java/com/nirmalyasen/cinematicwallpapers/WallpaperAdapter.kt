package com.nirmalyasen.cinematicwallpapers

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WallpaperAdapter(
    private val items: List<MainActivity.Wallpaper>,
    private val click: (MainActivity.Wallpaper) -> Unit
) : RecyclerView.Adapter<WallpaperAdapter.VH>() {
    class VH(v: View): RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.image)
        val name: TextView = v.findViewById(R.id.name)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_wallpaper, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, i: Int) {
        val w = items[i]
        h.image.setBackgroundColor(w.color)
        h.name.text = w.title
        h.itemView.setOnClickListener { click(w) }
    }
}
