# Cinematic Wallpapers
A starter Android app for cinematic wallpaper browsing.

Features:
- Dark cinematic UI
- 2-column wallpaper gallery
- Six starter categories/wallpaper cards
- Ready to extend with real images, favorites, downloads, and set-wallpaper actions

Build with Android Studio using the included Gradle project.
